
<?php $__env->startSection('content'); ?>
        <div class="container mt-3">

            <h3>Detail Data Mahasiswa !</h3>
                <!-- Form untuk edit data dengan value yang dapat menampilkan data berdasarkan id yang dibawa -->
                <form action="/home/<?php echo e($tbl_mahasiswa->id); ?>" method="post">
                    <?php echo method_field('put'); ?>
                    <?php echo csrf_field(); ?>
                    <label>NRP</label>
                    <input type="number" name="nrp" value="<?php echo e($tbl_mahasiswa->nrp); ?>" class="form-control" readonly>

                    <label>Nama</label>
                    <input type="text" name="nama" value="<?php echo e($tbl_mahasiswa->nama); ?>" class="form-control">
                    
                    <label>Email</label>
                    <input type="email" name="email" value="<?php echo e($tbl_mahasiswa->email); ?>" class="form-control">

                    <label>Alamat Mahasiswa</label>
                    <input type="text" name="alamat" value="<?php echo e($tbl_mahasiswa->alamat); ?>" class="form-control"><br>

                    <input type="submit" name="submit" value="update" class="btn btn-dark">
                </form>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ndah\OneDrive\Documents\semester 3\Pengembangan Aplikasi Web\Framework\Laravel\Modul-7\resources\views/tbl_mahasiswa/edit_data.blade.php ENDPATH**/ ?>