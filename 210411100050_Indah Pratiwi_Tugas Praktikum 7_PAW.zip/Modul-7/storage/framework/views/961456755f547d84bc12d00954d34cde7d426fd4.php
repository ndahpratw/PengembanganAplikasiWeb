<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
        <title>Home</title>
        <style type="text/css">
            body {
                background-color: gray;
                margin: 0px;
            } .main{
                min-height: 450px;
            } p {
                margin: 15px 50px;
                text-align: justify;
                text-indent: 45px;
                font-family: sans-serif;
            }

            /* Gambar */
            img:hover {
                transform: scale(1.15);
            }
        </style>
    </head>
    <body>
        <div class="header">
            <?php echo $__env->make('layout.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="main">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <div class="footer">
            <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </body>
</html><?php /**PATH C:\Users\ndah\OneDrive\Documents\semester 3\Pengembangan Aplikasi Web\Framework\Laravel\Modul-7\resources\views/layout/main.blade.php ENDPATH**/ ?>