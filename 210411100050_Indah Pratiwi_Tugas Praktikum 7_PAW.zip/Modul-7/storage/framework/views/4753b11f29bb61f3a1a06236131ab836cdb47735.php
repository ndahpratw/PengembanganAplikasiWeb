
<?php $__env->startSection('content'); ?>
    <title>Tambah Data</title>
        <div class="container mt-3">
            <!-- Form Untuk Tambah Data -->
            <div class="form">
                <h3>Isikan Data Berikut Dengan Benar !</h3>
                
                <form action="/home/proses_tambah_data" method="post">
                    <?php echo csrf_field(); ?>
                    <label>NRP</label>
                    <input type="number" class="form-control" name="nrp">

                    <label>Nama</label>
                    <input type="text" class="form-control" name="nama">

                    <label>Email</label>
                    <input type="email" class="form-control" name="email">

                    <label>Alamat</label>
                    <input type="text" class="form-control" name="alamat"><br>
                    
                    <input type="submit" name="kirim" value="tambah data" class="btn btn-dark">
                </form>
            </div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ndah\OneDrive\Documents\semester 3\Pengembangan Aplikasi Web\Framework\Laravel\Modul-7\resources\views/tbl_mahasiswa/tambah_data.blade.php ENDPATH**/ ?>