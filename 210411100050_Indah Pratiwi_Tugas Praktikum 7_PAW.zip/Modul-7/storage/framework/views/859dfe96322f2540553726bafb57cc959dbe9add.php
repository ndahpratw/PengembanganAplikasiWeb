
<?php $__env->startSection('contrainer'); ?>
<!DOCTYPE html>
<html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Tampil Data Pada Database</title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
      <style type="text/css">
        body{
          background-color: gray;
        
        } h2{
            text-align: center;
            text-shadow: 2px 1px 1px white;
            font-size: 35px;
        } p {
            text-align: center;
            color: white;
            margin-top:0px;
        } .kolom{
            background-color: white;
        } table{
            margin-top: 10px;
        } th, .aksi{
            text-align: center;
        } td{
            border: 1px solid black;
        }
        </style>
  </head>
  <body>
    <div class="container mt-3">

        <!-- Menampilkan Data Pada Tabel -->
        <table class="table">
        <h3>Data Mahasiswa</h3>
            <thead class="table-dark">
                <tr>
                    <th>No.</th>
                    <th>NRP</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Alamat</th>
                    <th>Operasi</th>
                </tr>
            </thead>
            <tbody>
                <!-- Menampilkan data yang ada di database -->
                <?php $__currentLoopData = $tbl_mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="kolom">
                    <td><?php echo e($mhs->id); ?></td>
                    <td><?php echo e($mhs->nrp); ?></td>
                    <td><?php echo e($mhs->nama); ?></td>
                    <td><?php echo e($mhs->email); ?></td>
                    <td><?php echo e($mhs->alamat); ?></td>
                    <td class="aksi">

                        <!-- Tombol Edit Data Mahasiswa -->
                        <a href="/home/<?php echo e($mhs->id); ?>/edit" class="btn btn-success">Edit</a>

                        <!-- Tombol Hapus Data Mahasiswa -->
                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#hapus<?php echo $mhs['nrp']?>">Hapus</button>
                        <div class="modal fade" id="hapus<?php echo $mhs['nrp']?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Hapus Data Mahasiswa</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                    <div class="modal-body">
                                    Apakah anda yakin untuk menghapus data dari <?php echo $mhs['nama'];?> ?
                                    </div>
                                <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tidak</button>
                                <form action="/home/<?php echo e($mhs->id); ?>" method="POST" class="btn btn-danger">
                                    <?php echo method_field('delete'); ?>
                                    <?php echo csrf_field(); ?>
                                    <input type="submit" value="delete">
                                </form>
                            </div>
                            </div>
                        </div>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

        <!-- Tombol Untuk Tambah Data -->
        <a href="/home/insert"><button type="button" class="btn btn-primary">Tambah Data</button></a>
    </div>
  </body>
</html>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ndah\OneDrive\Documents\semester 3\Pengembangan Aplikasi Web\Framework\Laravel\Modul-7\resources\views////layout/main.blade.php ENDPATH**/ ?>