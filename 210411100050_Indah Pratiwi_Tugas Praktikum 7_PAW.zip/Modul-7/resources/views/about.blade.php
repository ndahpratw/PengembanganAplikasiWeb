@extends('layouts.main')
@section('content')
    <title>About Me</title>
        <style type="text/css">

        /* Gambar */
        .foto_diri {
            width: 175px;
            border-style: solid;
            border-color: black;
            display: block;
            margin: auto;
        } img:hover {
            transform: scale(1.15);
        }

        h1 {
            text-align: left;
            width: 100%;
            margin: 10px 35px;
        }
        .saya {
            margin: 5px 518px;
            color:black;
            font-size: 30px;
        }

        p{
            margin: 10px 50px;
            text-align: justify;
            text-indent: 45px;
        }
        </style>

        <h1>About Me</h1>
        <img class='foto_diri' src="{{ 'storage/foto diri.png' }}" alt="indah pratiwi">
        <h2 class="saya"> Indah Pratiwi </h2>

        <h1>Background</h1>
        <p>
            Halooo ! Nama saya Indah Pratiwi. Biasa dipanggil Indah. Saya berasal dari Bangkalan. Saya merupakan anak pertama dari 3 bersaudara.
            Tepat di bulan lalu saya menginjak kepala dua, alias berusia 20 tahun hehe. Hobi saya adalah membaca dan scrool tiktok serta rebahan hehe. Buku yang sering dan biasa dibaca berjenis komik dan novel. 
            Selain buku fisik, saya juga sering membaca buku versi digital melalui aplikasi tertentu seperti wattpad dan weebton.
        </p>
        <p> 
            Saat ini saya sedang menempuh pendidikan S1 di Universitas Trunojoyo Madura. Saat SMA dulu, saya menjadi salah satu siswa eligible yang mendapat keuntungan untuk mendaftar kuliah melalui jalur SNMPTN. 
            Saat itu saya kebingungan untuk memilih program studi di kuliah nantinya. Akhirnya saya memantapkan keputusan saya untuk mendaftar SNMPTN dengan Teknik Informatika sebagai pilihan pertama dan Ilmu Kelautan sebagai pilihan kedua. 
            Seperti yang kita semua ketahui, era teknologi kini semakin maju membuat saya tidak ingin melewatkan kesempatan untuk berpartisipasi dalam belajar serta berkontribusi untuk mengembangkan teknologi. Akhirnya saya memilih Teknik Informatika sebagai program studi tujuan.
            Selain itu, prospek kerjanya pun sangat luas. Mungkin saja nantinya akan lebih cepat mendapat pekerjaan. Setelah pengumuman peserta lolos snmptn keluar, Alhamdulillah saya lolos dan segala urusan untuk mendaftar kuliah Allah lancarkan. 
            Lokasi kampus yang terbilang dekat membuat banyak orang merekomendasikan untuk masuk Universitas Trunojoyo Madura. Selain lokasinya yang dekat, akreditasinya pun bagus sehingga membuat saya memantapkan hati untuk berkuliah disini.
        </p>
        
        <h1>Suka Duka Praktikum PAW</h1>
        <p>
            Menurut saya, adanya praktikum pengembangan aplikasi ini sangat membantu saya untuk memahami lebih mengenai matakuliah yang sedang dijalankan.
            Adanya tugas pendahuluan membuat saya mengerti mengenai dasar dari hal yang sedang dipelajari. Begitu juga dengan tugas modul. Namun sayangnya untuk pelaksanaan praktikum ini terlalu malam.
            Selain itu, jadwal perkuliahan saya di hari Rabu sangat padat. Dimulai dari jam 07.00 sampai 18.00 sehingga terkadang ketika praktikum berlangsung saya kurang bisa mengikuti apa yang sedang dipaparkan.
            Waktu praktikum yang singkat juga membuat materi yang disampaikan harus cepat - cepat sehingga seringkali membuat saya dan mungkin teman - teman lain kurang bisa mengikut apa yang dipaparkan. 
            Meskipun begitu, saya mengucapkan terimakasih banyakk kepada para asisten praktikum yang telah bersedia mengajarkan materi - materi baru di setiap minggunya. Sehat selalu kakak kakak ehehe.
        </p>
@endsection