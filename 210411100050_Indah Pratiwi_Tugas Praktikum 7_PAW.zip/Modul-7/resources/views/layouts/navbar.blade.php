<style type="text/css">
    body {
        background-color: gray;
        margin: 0px;
    }

    /* Navbar */
    header{
        padding: 20px;
        background-color: #292929;
    } a {
        text-decoration: none; 
        color: black;
    } button {
        padding: 5px 20px;
        margin: 5px;
        border: 2px solid white;
        border-radius: 20px;
        font-weight: bold;
        transition: 0.5s;
        background-color: #999DA0;
        float:right;
    } button:hover {
        background-color: #3E424B;
        border: 2px solid #3E424B;
    } button.aktif{
        background-color: #3E424B;
        color: white;
    }
    h2{
        display: inline;
        color: #999DA0;
    }
</style>
<header>
    <!--MENU-->
    <h2>Simple Siakad</h2>
    <button><a href="/about">About Me</a></button>
    <button><a href="/home/insert">Input Data</a></button>
    <button><a href="/home">Data Mahasiswa</a></button>
</header>
