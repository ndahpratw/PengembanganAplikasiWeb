@extends('layouts.main')
@section('content')
        <div class="container mt-3">

            <h3>Detail Data Mahasiswa !</h3>
                <!-- Form untuk edit data dengan value yang dapat menampilkan data berdasarkan id yang dibawa -->
                <form action="/home/{{$tbl_mahasiswa->id}}" method="post">
                    @method('put')
                    @csrf
                    <label>NRP</label>
                    <input type="number" name="nrp" value="{{$tbl_mahasiswa->nrp}}" class="form-control" readonly>

                    <label>Nama</label>
                    <input type="text" name="nama" value="{{$tbl_mahasiswa->nama}}" class="form-control">
                    
                    <label>Email</label>
                    <input type="email" name="email" value="{{$tbl_mahasiswa->email}}" class="form-control">

                    <label>Alamat Mahasiswa</label>
                    <input type="text" name="alamat" value="{{$tbl_mahasiswa->alamat}}" class="form-control"><br>

                    <input type="submit" name="submit" value="update" class="btn btn-dark">
                </form>
        </div>
@endsection