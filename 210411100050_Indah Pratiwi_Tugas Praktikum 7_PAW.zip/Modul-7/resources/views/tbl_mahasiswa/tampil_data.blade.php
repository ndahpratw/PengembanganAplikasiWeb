@extends('layouts.main')

@section('content')
      <title>Tampil Data Pada Database</title>
      <style type="text/css">
        .kolom{
            background-color: white;
        } table{
            margin-top: 10px;
        } th, .aksi{
            text-align: center;
        } td{
            border: 1px solid black;
        }
        </style>
    <div class="container mt-3">

        <!-- Menampilkan Data Pada Tabel -->
        <table class="table">
        <h3>Data Mahasiswa</h3>
            <thead class="table-dark">
                <tr>
                    <th>No.</th>
                    <th>NRP</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Alamat</th>
                    <th>Operasi</th>
                </tr>
            </thead>
            <tbody>
                <!-- Menampilkan data yang ada di database -->
                @foreach ($tbl_mahasiswa as $mhs)
                <tr class="kolom">
                    <td>{{$mhs->id}}</td>
                    <td>{{$mhs->nrp}}</td>
                    <td>{{$mhs->nama}}</td>
                    <td>{{$mhs->email}}</td>
                    <td>{{$mhs->alamat}}</td>
                    <td class="aksi">

                        <!-- Tombol Edit Data Mahasiswa -->
                        <a href="/home/{{$mhs->id}}/edit" class="btn btn-success">Edit</a>

                        <!-- Tombol Hapus Data Mahasiswa -->
                        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#hapus<?php echo $mhs['nrp']?>">Hapus</button>
                        <div class="modal fade" id="hapus<?php echo $mhs['nrp']?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Hapus Data Mahasiswa</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                <div class="modal-body">
                                    Apakah anda yakin untuk menghapus data dari <?php echo $mhs['nama'];?> ?
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tidak</button>
                                    <form action="/home/{{$mhs->id}}" method="POST" class="btn btn-danger">
                                        @method('delete')
                                        @csrf
                                        <input type="submit" value="delete">
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
@endsection