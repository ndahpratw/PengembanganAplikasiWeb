<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Tbl_mahasiswa;

class Tbl_mahasiswaController extends Controller
{
    public function tampil_data()
    {
        $tbl_mahasiswa = Tbl_mahasiswa::all();
        // dd($tbl_mahasiswa);
        return view ('tbl_mahasiswa.tampil_data',compact(['tbl_mahasiswa']));
    }

    public function insert()
    {
        return view ('tbl_mahasiswa.tambah_data');
    }

    public function tambah(Request $request)
    {
        // dd($request->all());
        Tbl_mahasiswa::create($request->except(['token', 'submit']));
        return redirect('/home');
    }

    public function edit($id)
    {
        // dd($id);
        $tbl_mahasiswa = Tbl_mahasiswa::find($id);
        return view ('tbl_mahasiswa.edit_data', compact(['tbl_mahasiswa']));
    }

    public function update($id, Request $request)
    {
        $tbl_mahasiswa = Tbl_mahasiswa::find($id);
        $tbl_mahasiswa->update($request->except(['token', 'submit']));
        // dd($tbl_mahasiswa); 
        return redirect('/home');
    }

    public function destroy($id)
    {
        $tbl_mahasiswa = Tbl_mahasiswa::find($id);
        $tbl_mahasiswa->delete();
        return redirect('/home');
    }
}